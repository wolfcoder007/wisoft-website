<?php

namespace Modules\User\Exceptions;

use Exception;

class InvalidOrExpiredResetCode extends Exception
{
}
