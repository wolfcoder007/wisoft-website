<?php

namespace Modules\User\Exceptions;

use Exception;

class UserNotFoundException extends Exception
{
}
