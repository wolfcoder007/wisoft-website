<?php

require __DIR__ . '/Http/routes.php';
require __DIR__ . '/composers.php';
