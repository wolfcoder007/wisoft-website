<?php

namespace Modules\Core\Foundation;

class AsgardCms
{
    /**
     * The AsgardCms version.
     * @var string
     */
    const VERSION = '4.0.0';
}
