<?php

namespace Modules\Workshop\Manager;

interface ThemeManager
{
    /**
     * Get all themes
     * @return array
     */
    public function all();
}
