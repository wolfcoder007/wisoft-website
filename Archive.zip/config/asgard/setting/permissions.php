<?php

return [
    'setting.settings' => [
        'index' => 'setting::settings.list resource',
        'edit' => 'setting::settings.edit resource',
    ],
];
