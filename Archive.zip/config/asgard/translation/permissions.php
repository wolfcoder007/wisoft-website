<?php

return [
    'translation.translations' => [
        'index' => 'translation::translations.list resource',
        'edit' => 'translation::translations.edit resource',
        'import' => 'translation::translations.import resource',
        'export' => 'translation::translations.export resource',
    ],
];
