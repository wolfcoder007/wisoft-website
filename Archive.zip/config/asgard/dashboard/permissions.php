<?php

return [
    'dashboard' => [
        'index' => 'dashboard::dashboard.list resource',
        'update' => 'dashboard::dashboard.edit resource',
        'reset' => 'dashboard::dashboard.reset resource',
    ],
];
