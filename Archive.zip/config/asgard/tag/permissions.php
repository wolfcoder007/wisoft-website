<?php

return [
    'tag.tags' => [
        'index' => 'tag::tags.list resource',
        'create' => 'tag::tags.create resource',
        'edit' => 'tag::tags.edit resource',
        'destroy' => 'tag::tags.destroy resource',
    ],
];
