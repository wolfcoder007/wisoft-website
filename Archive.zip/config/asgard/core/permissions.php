<?php

return [
    'core.sidebar' => [
        'group' => 'core::sidebar.show group',
    ],
];
