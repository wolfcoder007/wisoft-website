<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\DashboardServiceProvider',
    1 => 'Modules\\Dashboard\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Dashboard\\Providers\\WidgetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\DashboardServiceProvider',
    1 => 'Modules\\Dashboard\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Dashboard\\Providers\\WidgetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);