<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Tag\\Providers\\TagServiceProvider',
    1 => 'Modules\\Tag\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Tag\\Providers\\TagServiceProvider',
    1 => 'Modules\\Tag\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);