<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Workshop\\Providers\\RouteServiceProvider',
    1 => 'Modules\\Workshop\\Providers\\WorkshopServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Workshop\\Providers\\RouteServiceProvider',
    1 => 'Modules\\Workshop\\Providers\\WorkshopServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);