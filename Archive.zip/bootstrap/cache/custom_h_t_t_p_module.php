<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomHTTP\\Providers\\CustomHTTPServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomHTTP\\Providers\\CustomHTTPServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);