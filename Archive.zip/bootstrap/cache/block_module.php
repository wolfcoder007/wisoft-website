<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Block\\Providers\\BlockServiceProvider',
    1 => 'Modules\\Block\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Block\\Providers\\BlockServiceProvider',
    1 => 'Modules\\Block\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);