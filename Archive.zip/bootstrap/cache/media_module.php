<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    1 => 'Modules\\Media\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Media\\Image\\ImageServiceProvider',
    3 => 'Intervention\\Image\\ImageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Media\\Providers\\MediaServiceProvider',
    1 => 'Modules\\Media\\Providers\\RouteServiceProvider',
    2 => 'Modules\\Media\\Image\\ImageServiceProvider',
    3 => 'Intervention\\Image\\ImageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);